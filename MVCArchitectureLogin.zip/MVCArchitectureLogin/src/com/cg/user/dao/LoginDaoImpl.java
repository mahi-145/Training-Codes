package com.cg.user.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.user.dto.Login;
import com.cg.user.exception.LoginException;
import com.cg.user.util.DbUtil;

public class LoginDaoImpl implements LoginDao
{
	Connection conn=null;
	PreparedStatement pst=null;
	ResultSet rs=null;

	@Override
	public Login getUserByUnm(String unm) throws LoginException
	{
		Login user=null;
		try
		{
			conn=DbUtil.getConn();
			System.out.println("Connection Established");
			String qry="select * from user_142233 where user_id=?";
			pst=conn.prepareStatement(qry);
			pst.setString(1, unm);
			rs=pst.executeQuery();
			rs.next();
			user=new Login(rs.getString("user_id"), rs.getString("password"));
		}
		catch(SQLException e)
		{
			throw new LoginException(e.getMessage());
		}
		return user;
		
	}
}
