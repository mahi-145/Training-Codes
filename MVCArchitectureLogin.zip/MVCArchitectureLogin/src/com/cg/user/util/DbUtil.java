package com.cg.user.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.sql.DataSource;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.cg.user.exception.LoginException;

public class DbUtil 
{
	public static Connection getConn() throws LoginException
	{
		Connection conn = null;
		InitialContext context;
	//	conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
	
		try 
		{
			context=new InitialContext();
			DataSource ds=(DataSource)context.lookup("java:/JDBC/OracleDS");
			conn=ds.getConnection();
		}
		catch (Exception e) 
		{
			throw new LoginException(e.getMessage());
		}
		
		return conn;
	}
	
	
}
