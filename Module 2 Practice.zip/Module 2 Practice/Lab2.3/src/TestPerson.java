
public class TestPerson {

	public static void main(String[] args) 
	{
		Person p1=new Person("Divya","Bharti",'F');
		
		System.out.println("Person Details: ");
		System.out.println("___________________");
		System.out.println("First Name: "+p1.getFirstName()); // for calling ..getter function is used
		System.out.println("Last Name: "+p1.getLastName());
		System.out.println("Gender: "+p1.getGender());

	}

}
