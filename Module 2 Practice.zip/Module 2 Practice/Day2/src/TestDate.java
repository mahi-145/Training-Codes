import java.util.Scanner;
public class TestDate 
{

	public static void main(String[] args) 
	{
		
		Scanner sc =new Scanner(System.in);
		/*for(int i=0;i<3;i++)
		{
			System.out.println("Enter your name");
			String name=sc.next();
			
			System.out.println("Enter Day:");
			int dayOfDoj=sc.nextInt();
			
			System.out.println("Enter Month:");
			int monOfDoj=sc.nextInt();
			
			System.out.println("Enter Year:");
			int yearOfDoj=sc.nextInt();
			
			Date names =new Date(dayOfDoj,monOfDoj,yearOfDoj);//Object Creation line 
			System.out.println(name+" your DOJ :"+names.dispDate());
		}*/
		
		Date allDojs[]=new Date[3];
		String names[]=new String[3];
		
		for(int i=0;i<allDojs.length;i++)
		{
			System.out.println("Enter your name");
			names[i]=sc.next();
			
			System.out.println("Enter Day of joining:");
			int day=sc.nextInt();
			
			System.out.println("Enter Month of joining:");
			int mon=sc.nextInt();
			
			System.out.println("Enter Year of joining:");
			int year=sc.nextInt();
			
			allDojs[i]=new Date(day,mon,year);
		}
		
		for(int j=0;j<allDojs.length;j++)
		{
			System.out.println(names[j]+" Your DOJ is : "+allDojs[j].dispDate());
		}
		
		


	}

}
