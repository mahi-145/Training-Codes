import java.util.Scanner;
public class TestDateDemo {

	public static void main(String[] args) 
	{
		Scanner sc =new Scanner(System.in);
		
		System.out.println("Enter Day:");
		int dayOfDoj=sc.nextInt();
		
		System.out.println("Enter Month:");
		int monOfDoj=sc.nextInt();
		
		System.out.println("Enter Year:");
		int yearOfDoj=sc.nextInt();
		
		Date MahiDOJ =new Date(dayOfDoj,monOfDoj,yearOfDoj);
		System.out.println(" your DOJ :"+MahiDOJ.dispDate());
		
		System.out.println("*********************************");
		
		System.out.println("Enter Day:");
		dayOfDoj=sc.nextInt();
		
		System.out.println("Enter Month:");
		monOfDoj=sc.nextInt();
		
		System.out.println("Enter Year:");
		 yearOfDoj=sc.nextInt();
		
		Date AniDOJ =new Date(dayOfDoj,monOfDoj,yearOfDoj);
		System.out.println(" Anindita DOJ :"+AniDOJ.dispDate());

	}

}
