

public class Syrup extends Medicine
{
	public Syrup()
	{
		super();
	}
	public Syrup(String medName, String cmpName, String date, float medPrice)
	{
		super( medName,cmpName,date,medPrice);
	}
	public String dispMedInfo()
	{
		return super.dispMedInfo()+"\n Shake Well Before Use";
	}
}
