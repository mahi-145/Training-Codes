import java.util.Scanner;
public class TestMedicine {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("How Many Medicines");
		int medCount=sc.nextInt();
		String medName=null;String cmpName=null;String date=null; float medPrice=0.0f;
		Medicine medArr[]=new Medicine[medCount];
		
		for(int i=0;i<medArr.length;i++)
		{
			System.out.println("Enter Medicine Name:");
			medName=sc.next();
			
			System.out.println("Enter Company Name:");
			cmpName=sc.next();
			
			System.out.println("Enter Medicine Price:");
			medPrice=sc.nextFloat();
			
			System.out.println("Enter Expiry date:");
			date=sc.next();
			
		System.out.println("What type of Medicine ?"+"1.Tablet\t2:Ointment\t 3:Syrup");
			
			System.out.println("Enter Choice:");
			int choice=sc.nextInt();
			
			switch(choice)
			{
			case 1:		medArr[i]=new Tablet(medName,cmpName,date,medPrice);
						break;
				
			case 2:		medArr[i]=new Ointment(medName,cmpName,date,medPrice);
				 		break;
				
			default: 
						medArr[i]=new Syrup(medName,cmpName,date,medPrice);
						break;
				
			}
			
		}
		System.out.println("*****************");
		for(int j=0;j<medArr.length;j++)
			
		{
			if(medArr[j] instanceof Syrup)
			{	
				System.out.println("Syrup: \t"+medArr[j].dispMedInfo());
			}		                                                                                                                                                                                                                                               
			else if(medArr[j] instanceof Ointment)
			{
				System.out.println("Ointment: \t"+medArr[j].dispMedInfo());
			}
			else
			{
				System.out.println("Tablet: \t"+medArr[j].dispMedInfo());
			}
					
					
		}
		
		
	}

}
