import java.util.Scanner;
public class Medicine 
{
	private String medName;
	private String cmpName;
	private String date;
	private float medPrice;
	
	public Medicine()
	{}

	public Medicine(String medName, String cmpName, String date, float medPrice) 
	{
		super();
		this.medName = medName;
		this.cmpName = cmpName;
		this.date = date;
		this.medPrice = medPrice;
	}
	public String dispMedInfo() {
		return "Medicine [medName=" + medName + ", cmpName=" + cmpName
				+ ", date=" + date + ", medPrice=" + medPrice + "]";
	};
	
	
	
}
