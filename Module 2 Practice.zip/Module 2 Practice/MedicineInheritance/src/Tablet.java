
public class Tablet extends Medicine
{
	public Tablet()
	{
		super();
	}
	public Tablet(String medName, String cmpName, String date, float medPrice)
	{
		super( medName,cmpName,date,medPrice);
	}
	public String dispMedInfo()
	{
		return super.dispMedInfo()+"\n It should be stored in Cold Place";
	}
}
