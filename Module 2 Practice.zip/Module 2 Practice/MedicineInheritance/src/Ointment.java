
public class Ointment extends Medicine
{
	public Ointment()
	{
		super();
	}
	public Ointment(String medName, String cmpName, String date, float medPrice)
	{
		super( medName,cmpName,date,medPrice);
	}
	public String dispMedInfo()
	{
		return super.dispMedInfo()+"\n Use twice a Day and store in a cool place";
	}
}
