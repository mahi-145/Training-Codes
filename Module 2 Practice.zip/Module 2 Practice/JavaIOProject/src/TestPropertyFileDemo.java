import java.io.IOException;
import java.io.FileReader;
import java.util.Properties;

public class TestPropertyFileDemo 
{

	public static void main(String[] args) 
	{
		FileReader fr=null;
		Properties props=null;
		try
		{
			fr=new FileReader("userInfo.properties");
			props=new Properties();
			props.load(fr);		//overloaded object
			
			System.out.println("All data ");
			
//Enumeration is used when we don't know what is written in the property file.//
			
			String unm=props.getProperty("username");
			String pswd=props.getProperty("password");
			String loc=props.getProperty("location");
			String st=props.getProperty("state");
				
			System.out.println("User Info \nUsername: "+unm+"\nPassword: "
			+pswd+"\nLocation: "+loc+"\nState: "+st);
			
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		

	}

}
