import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Scanner;
public class TestnSerializationDemo 
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter no of Employees");
		int n=sc.nextInt();
		
		Emp empArr[]=new Emp[n];
		
		for(int i=0;i<empArr.length;i++)
		{
			System.out.println("Enter Emp Id:");
			int empId =sc.nextInt();
			
			System.out.println("Enter Emp Name:");
			 String empName =sc.next();
			
			System.out.println("Enter Emp Salary:");
			 float empSal =sc.nextFloat();
			
			 empArr[i]= new Emp(empId,empName,empSal);
		}
		FileOutputStream fos;
		ObjectOutputStream oos;
		try
		{
			fos=new FileOutputStream("EmpData.obj");
			oos=new ObjectOutputStream(fos);
			
			for(int i=0;i<empArr.length;i++)
				oos.writeObject(empArr[i]);
			
			System.out.println("Emp Object is written in a file");
		}
		catch(IOException er)
		{
			er.printStackTrace();
		}
		
	}
}
