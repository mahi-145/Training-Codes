import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;


public class TestnDeserialization 
{

	public static void main(String[] args) 
	{
		
		FileInputStream fis;
		
		Emp er[]=null;
		int i=0;
		
		try
		{
			ObjectInputStream ois=null;
			fis=new FileInputStream("EmpData.obj");
			ois=new ObjectInputStream(fis);
			
			while(er[i]!=null)
			{
				er[i]=(Emp)ois.readObject();
				i=i+1;
			} 
		}
		catch (ClassNotFoundException e) 
		{
				
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
				
			e.printStackTrace();
		}
			
		

	}

}
