import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Scanner;


public class Test3EmpDeserialization 
{
	public static void main(String[] args) 
	{
		Emp er[]=new Emp[3];
			FileInputStream fis;
		
			try
			{
				fis=new FileInputStream("EmpData.obj");
				ObjectInputStream ois=new ObjectInputStream(fis);
				
				for(int i=0;i<3;i++)
				{
					er[i] = (Emp)ois.readObject();
				
					System.out.println("Emp Object is read in a file"+er[i]);
				}
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
			catch(ClassNotFoundException e)
			{
				e.printStackTrace();
			}
		}
		
	}

