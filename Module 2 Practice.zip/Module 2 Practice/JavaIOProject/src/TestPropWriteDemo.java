import java.io.IOException;
import java.io.FileWriter;
import java.util.Properties;

public class TestPropWriteDemo 
{

	public static void main(String[] args) 
	{
		FileWriter fw=null;
		Properties pw=null;
		try
		{
			 fw=new FileWriter("dbInfo.properties");
			 pw=new Properties();
			 pw.setProperty("dbUrl","jdbc:oracle:thin");
			 pw.setProperty("dbUsername", "system");
			 pw.setProperty("dbPwd","root");
			 pw.store(fw,"this is Oracle"+" DB creadialities");
			 System.out.println("Data written in property file");
		
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		

	}

}
