
public class TestInheritanceDemo {

	public static void main(String[] args) 
	{
		
		/*Employee e1=null;
		e1=new Employee(333,"Pari",60000.0f);
		WageEmp e2=null;
		e2=new WageEmp(555,"Sunita",5000.0f,3,500);
		Employee e3=null;
		e3=new WageEmp(666,"Amit",5000.0f,4,500);
		WageEmp we=(WageEmp)e3;*/
		
		Employee Vaishali=new Employee(111,"Vaish",23000.0f);
		WageEmp Babitha = new WageEmp(122,"Babz",5000.0f,5,500);
		SalesMng Mahi =new SalesMng(133,"Mahima",5000.0f,5,500,4000,2f);
		
		System.out.println("Emp Info:"+Vaishali.dispEmpInfo());
		System.out.println("Emp Month Salary:"+Vaishali.calcEmpBasicSal());
		System.out.println("Emp Annual Sal:"+Vaishali.calcEmpAnnualSal());
		
		System.out.println("Emp Info:"+Babitha.dispEmpInfo());
		System.out.println("Emp Month Salary:"+Babitha.calcEmpBasicSal());
		System.out.println("Emp Annual Salary:"+Babitha.calcEmpAnnualSal());
		
		System.out.println("Emp Info:"+Mahi.dispEmpInfo());
		System.out.println("Emp Month Salary:"+Mahi.calcEmpBasicSal());
		System.out.println("Emp Annual Salary:"+Mahi.calcEmpAnnualSal());
		
		
		/*System.out.println();
		//Dynamic POlymorphism
		Employee kritika = new WageEmp(444,"Kritika",5000.0f,7,500);
		System.out.println("Emp Info:"+kritika.dispEmpInfo());
		System.out.println("Emp Month Salary:"+kritika.calcEmpBasicSal());
		System.out.println("Emp Annual Salary:"+kritika.calcEmpAnnualSal());*/
		

	}

}
