import java.util.Scanner;
public class TestInheritanceDemoArray 
{

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("How many Employees?");
		int empCount=sc.nextInt();
		
		Employee empArr[]=new Employee[empCount];
		
		int eId=0; int ratePerHrs=0; int noOfHrs=0; int sale=0; int comm=0;
		String enm=null;
		float esal=0.0f;
		
		for(int i=0;i<empArr.length;i++)
		{
			System.out.println("Enter Emp Id:");
			eId=sc.nextInt();
			System.out.println("Enter Emp Name:");
			enm=sc.next();
			System.out.println("Enter Emp Salary:");
			esal=sc.nextFloat();
			
			System.out.println("What type of Employee u want?"+"1.Emp\t2:WageEmp\t 3:SalesMgr");
			
			System.out.println("Enter Choice:");
			int choice=sc.nextInt();
			
			switch(choice)
			{
			case 1:		empArr[i]=new Employee(eId,enm,esal);
						break;
				
			case 2:		System.out.println("Enter no of hours u worked");
				 		noOfHrs=sc.nextInt();
				 		System.out.println("Enter rate per hour");
				 		ratePerHrs=sc.nextInt();
				
				 		empArr[i]=new WageEmp(eId,enm,esal,noOfHrs,ratePerHrs);
				 		break;
				
			default: 
						System.out.println("Enter no of hours u worked");
						noOfHrs=sc.nextInt();
						
						System.out.println("Enter rate per hour");
						ratePerHrs=sc.nextInt();
						
						System.out.println("Enter Sales You have done");
						sale=sc.nextInt();
						
						System.out.println("Enter commision");
						comm=sc.nextInt();
						
						empArr[i]=new SalesMng(eId,enm,esal,noOfHrs,ratePerHrs,sale,comm);
						break;
				
			}
			
		}
		System.out.println("*****************");
		for(int j=0;j<empArr.length;j++)
			
		{
			if(empArr[j] instanceof SalesMng)
			{	
				System.out.println("Sales Manager: \t"+empArr[j].dispEmpInfo()+
						" \t                                                                                                                                                                                                                                                      Monthly basic Sal:\t"+empArr[j].calcEmpBasicSal()+
						" \tAnnual Sal:\t "+empArr[j].calcEmpAnnualSal());
			}
			else if(empArr[j] instanceof WageEmp)
			{
				System.out.println("Wage Emp: \t"+empArr[j].dispEmpInfo()+
						" \tMonthly basic Sal:\t"+empArr[j].calcEmpBasicSal()+
						" \tAnnual Sal: \t"+empArr[j].calcEmpAnnualSal());
			}
			else
			{
				System.out.println("Employee: \t"+empArr[j].dispEmpInfo()+
						"\t Monthly basic Sal:\t"+empArr[j].calcEmpBasicSal()+
						"\t Annual Sal: \t"+empArr[j].calcEmpAnnualSal());
			}
					
					
		}
		
		
	}

}
