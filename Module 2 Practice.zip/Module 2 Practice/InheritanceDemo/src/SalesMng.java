
public class SalesMng extends WageEmp
{
	private int sale;
	private float comm;
	
	public SalesMng() 
	{
		super();
	}
	public SalesMng(int empId,String empName,float empSal,int noOfHrs,int ratePerHrs,int sale,float comm)
	{
		super(empId,empName,empSal,noOfHrs,ratePerHrs);
		this.sale=sale;
		this.comm=comm;
	}
	public float calcEmpBasicSal()
	{
		return super.calcEmpBasicSal() + (sale*comm);
	}
	public float calcEmpAnnualSal()
	{
		return calcEmpBasicSal()*12;
	}
	
}
