
public class Emp 
{
	private int empId;
	private String empName;
	private float empSal;
	static int empCount;
	/**************************************Static Block Starts*********************/
	
	static 
	{
		System.out.println("Emp Static block:");
		empCount=5;									//Initial value 
	}
	
	/**********************************Static Block Ends****************************************/
	public int getEmpId() 
	{
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public float getEmpSal() {
		return empSal;
	}
	public void setEmpSal(float empSal) {
		this.empSal = empSal;
	}
	public Emp(int empId, String empName, float empSal)
	{
		
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
		empCount++;
	}
	public Emp()
	{}
	
	
	public String dispEmpInfo() 
	{
		return "Emp [empId=" + empId + 
				", empName=" + empName + 
				", empSal="
				+ empSal + "Emp Count:"+empCount+"]";
	}
	
	public static void  getCount()
	{
		System.out.println("Emp count is :"+empCount);
		//System.out.println("Emp Id is :"+empId);	//Only static variable can be called in static function
	}
	
	
}
