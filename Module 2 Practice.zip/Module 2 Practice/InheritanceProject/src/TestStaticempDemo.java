
public class TestStaticempDemo 
{
	static
	{
		System.out.println("this is TestStaticempDemo static block");
	}
	private static void name()
	{
		System.out.println("Hey");
	}
	public static void main(String[] args)
	{
		System.out.println("Main starts here");
		Emp e1=new Emp(111,"Mahima",1200.0f);
		Emp e2= new Emp(222,"Mad",2000.0f);
		Emp e3=new Emp(333,"Praggy",4000.0f);
		
		
		System.out.println(e1.dispEmpInfo());
		System.out.println(e2.dispEmpInfo());
		System.out.println(e3.dispEmpInfo());
		//name();
		Emp.getCount();
		// int id=e1.empId;

	}

}
