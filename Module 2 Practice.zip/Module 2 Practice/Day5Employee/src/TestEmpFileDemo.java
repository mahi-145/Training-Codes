import java.io.*;
public class TestEmpFileDemo {

	public static void main(String[] args) 
	{
		try
		{
			InputStreamReader isr=new InputStreamReader(System.in);
			BufferedReader br=new BufferedReader(isr);
			
			System.out.println("Enter Emp Id");
			int eid=Integer.parseInt(br.readLine());
			
			System.out.println("Enter Emp Name");
			String enm=br.readLine();
			
			System.out.println("Enter Emp Salary");
			float eSal=Float.parseFloat(br.readLine());
			
			System.out.println(eid+" "+enm+" "+eSal);
			
			FileWriter fw=new FileWriter("EmployeeInfo.txt");
			BufferedWriter bw=new BufferedWriter(fw);
			
			Integer eId=new Integer(eid); //boxing(converting primitive type into Integer)
			Float eSl= new Float(eSal);
			
			bw.write(eId.toString());
			bw.write(enm);
			bw.write(eSl.toString());
			bw.newLine();
			bw.flush();
			
			System.out.println("Emp info written");
			
		} 
	
		catch (IOException e) 
		{
			
			e.printStackTrace();
		}

	}

}
