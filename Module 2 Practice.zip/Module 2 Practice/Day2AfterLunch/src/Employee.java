
public class Employee
{
		private int empId;
		//private String empName;
		private char empGender;
		private float empSalary;

		public Employee()
		{
			empId=0;
			//empName="unknown";
			empGender=' ';
			empSalary=0.0f;
			
		}
		public Employee(int id,  char g,float sal)
		{
			this();
			this.empId = id;
			//this.empName= en;
			this.empGender = g;
			this.empSalary =sal;
		}
		public void dispRecord()
		{
			System.out.println("Employee Id: "+empId+" Employee Gender: "+empGender+" Employee Salary: "+empSalary);
		}
}