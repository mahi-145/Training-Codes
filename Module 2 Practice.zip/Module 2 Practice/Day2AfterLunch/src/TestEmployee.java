import java.util.Scanner;


public class TestEmployee
{

	public static void main(String[] args)
	{
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter the number of Employees");
		int n=sc.nextInt();
		
		Employee allEmps[]=new Employee[n];
		String names[]=new String[n];
		
		for(int i=0;i<names.length;i++)
		{
			System.out.println("Enter Employee's name:");
			names[i]=sc.next();
			
			System.out.println("Enter employee Id:");
			int empId=sc.nextInt();
			
			System.out.println("Enter Gender of Employee:");
			String empgen=sc.next();
			char gender=empgen.charAt(0);
			
			System.out.println("Enter Salary of Employee:");
			float empSal=sc.nextFloat();
			
			allEmps[i]=new Employee(empId,gender,empSal);
		}
		
		for(int j=0;j<allEmps.length;j++)
		{
			System.out.println(names[j]+"Your Record is as follow");
			allEmps[j].dispRecord();
		}

	}

}
