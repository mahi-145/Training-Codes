
public class TestEmpAggregationDemo 
{

	public static void main(String[] args) 
	{
		Date vaiDoJ=new Date(01,04,2015);
		Date rosh=new Date(13,12,2017);
		
		Employee1 vaishali = new Employee1(112081,"Vaishali S",1000.0f,vaiDOJ);
		
		Employee1 Roshan = new Employee1(11081,"Roshan ",1000.0f,rosh);
		
		System.out.println(vaishali.dispEmpInfo());
		System.out.println(Roshan.dispEmpInfo());

	}

}
