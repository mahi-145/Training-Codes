public class Date 
{
	private int day;
	private int mon;
	private int year;
	
	public Date()
	{
		
	}
	public Date(int dd,int mm,int yy)
	{
		this.day=dd;
		this.mon=mm;
		this.year=yy;
	}
	public String dispDate()
	{
		return day+"-"+mon+"-"+year;
	}
}
