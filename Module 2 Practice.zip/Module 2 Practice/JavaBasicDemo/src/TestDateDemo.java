
public class TestDateDemo 
{

	public static void main(String[] args) 
	{
		Date mahiDOJ= new Date(13, 12, 2017);
		System.out.println("Mahima DOJ is: "+mahiDOJ.dispDate());
		
		Date vaiDOJ= new Date(03, 04, 2013);
		System.out.println("Vaishali DOJ is: "+vaiDOJ.dispDate());
		
		Date unknownPerson=new Date();
		System.out.println("unknownPerson DOJ is: "+unknownPerson.dispDate());
		
	}

}
