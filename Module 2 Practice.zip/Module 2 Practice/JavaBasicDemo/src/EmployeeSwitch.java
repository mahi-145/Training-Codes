
public class EmployeeSwitch {

	public static void main(String[] args) 
	{
		Employee emp1= new Employee(12,"Mahima",'F',3000);
		System.out.println("Details are:"+emp1.dispRecord());
		
		Employee emp2= new Employee(13,"Anindita",'F',4000);
		System.out.println("Details are:"+emp2.dispRecord());
		
		Employee emp3= new Employee();
		System.out.println("Details are:"+emp3.dispRecord());
	}

}
