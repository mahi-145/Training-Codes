
public class Person
{
	private String firstName;
	private String lastName;
	private char perGender;
	private int perAge;
	private float perWeight;
	
	public Person(String fn, String ln, char gen,int age,float wg)
	{
		firstName=fn;
		lastName=ln;
		perGender=gen;
		perAge=age;
		perWeight=wg;
	}
	public void dispRecord()
	{
		System.out.println("Person Details:");
		System.out.println("__________________");
		System.out.println("First Name:"+firstName);
		System.out.println("Last Name:"+lastName);
		System.out.println("Gender:"+perGender);
		System.out.println("Age:"+perAge);
		System.out.println("Weight:"+perWeight);	
	}
	public static void main(String[] args) 
	{
		Person per= new Person("Divya","Bharti",'F',20,85.55f);
		per.dispRecord();	
	}
}
