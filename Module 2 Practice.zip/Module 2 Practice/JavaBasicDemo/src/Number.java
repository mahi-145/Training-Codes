
public class Number {

	public static void main(String[] args) 
	{
		int num=Integer.parseInt(args[0]);
		
		if(num>0)
			System.out.println("Entered Number "+num+" is positive");
		else 
			System.out.println("Entered Number "+num+" is negative");

	}

}
