
public class TestStudentBeanDemo {

	public static void main(String[] args) 
	{
		/*Empty constructor but we didn't write in object class .
		object is creating by default constructor*/
		Student s1=new Student();	
		s1.setRollNo(111);			//for initialization setter function is used
		s1.setStuName("Mahima");
		s1.setMark(45);
		
		System.out.println("Roll No:"+s1.getRollNo()); // for calling ..getter function is used
		System.out.println("Student Name:"+s1.getStuName());
		System.out.println("Student marks:"+s1.getMark());
		

	}

}
