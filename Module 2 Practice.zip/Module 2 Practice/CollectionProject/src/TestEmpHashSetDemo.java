//Not unique but random output
import java.util.*;
public class TestEmpHashSetDemo 
{

	public static void main(String[] args) 
	{
		HashSet<Emp> empSet = new HashSet<Emp>();
		
		Emp e1 = new Emp(142970, "VIDIT KUMAR", 5000.0F);
		Emp e2 = new Emp(142309, "VASU SHARMA", 10000.0F);
		Emp e3 = new Emp(142999, "MAHIMA", 100000.0F);
		Emp e4 = new Emp(142555, "ASHUTOSH", 20000.0F);
		Emp e5 = new Emp(142444, "BRISTI", 50000.0F);
		Emp e6 = new Emp(142444, "BRISTI", 50000.0F);
		
//Reference of stack is generated which is unique that's why all entries are printing
		empSet.add(e1);	 
		empSet.add(e2);
		empSet.add(e3);
		empSet.add(e4);
		empSet.add(e5);
		empSet.add(e6);
		
		for(Emp tempE: empSet)
		{
			System.out.println(tempE);
		}
		
	}

	}


