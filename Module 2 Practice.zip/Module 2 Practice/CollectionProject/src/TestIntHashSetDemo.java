//In this program we'll get only unique values randomly;
//As we are giving 5 values but '5' is common so only 4 value will print;
import java.util.*;
public class TestIntHashSetDemo 
{

	public static void main(String[] args)
	{
		HashSet<Integer>intSet=new HashSet<Integer>();
		
		Integer i1 = new Integer(10);
		Integer i2 = new Integer(5);
		Integer i3 = new Integer(56);	
		Integer i4 = new Integer(34);
		Integer i5 = new Integer(5);
		
		intSet.add(i1);
		intSet.add(i2);
		intSet.add(i3);
		intSet.add(i4);
		intSet.add(i5);
		
		System.out.println("********* Without Iterator ***********");
		System.out.println(intSet);
		System.out.println("********* With Iterator **************");
		
		Iterator<Integer> it = intSet.iterator();
		
		while (it.hasNext())
		{
			Integer tempEntry = (Integer)it.next();
			System.out.println("  :  " + tempEntry);
		}
		
	}

	}


