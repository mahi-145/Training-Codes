public class Fact
{

	public static void main(String ar[])

	{

		int number = Integer.parseInt(ar[0]);
		int index ;
		int factorial =1;
		
		for(index=1; index <= number;index++)
		{
			factorial = factorial * index;
		}
		System.out.println("Factorial of entered number is "+factorial);
	}
}

