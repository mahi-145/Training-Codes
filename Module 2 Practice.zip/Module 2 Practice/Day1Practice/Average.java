public class Average
{

	public static void main(String ar[])

	{

		int number,index,n;
		float avg,sum=0;
		n= Integer.parseInt(ar[0]);
		
		for(index=1; index <=n;index++)
		{
			number = Integer.parseInt(ar[index]);
			sum = sum + number;
		}
		avg= sum/n;
		
		System.out.println("Average of "+n + " number is  "+avg);
	}
}

