public class TestIfDemo
{

	public static void main(String ar[])

	{

		int marks = Integer.parseInt(ar[0]) ;
		
	

		if(marks < 40)
		
			System.out.println ("You are fail");

		else if((marks >= 40) && (marks<60))
		
			System.out.println("Fail");
		
		else if((marks >= 60) && (marks < 75))
			
			System.out.println("First Class");
		
		else if ((marks >= 75) && (marks < 100))
			
			System.out.println("You got distinction");
		else 
			
			System.out.println("Wrong input i.e. Greater than 100");

	}
}

