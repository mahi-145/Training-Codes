

public class Person 
{
	private String firstName;
	private String lastName;
	private char gender;
	private long phoneNo;
	
	
	public Person(String firstName, String lastName, char gender, long phoneNo)
	{
		setFirstName(firstName);
		setLastName(lastName);
		setGender(gender);
		setPhoneNo(phoneNo);
	}

	public Person()
	{
	
	}

	public String getFirstName() 
	{
		return firstName;
	}

	public void setFirstName(String firstName) 
	{
		this.firstName = firstName;
	}

	public String getLastName() 
	{
		return lastName;
	}

	public void setLastName(String lastName) 
	{
		this.lastName = lastName;
	}

	public char getGender() 
	{
		return gender;
	}

	public void setGender(char gender) 
	{
		this.gender = gender;
	}
	public long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}

	public void dispPerson()
	{
		System.out.println("Person Details: ");
		System.out.println("___________________");
		System.out.println("First Name: "+getFirstName()); 
		System.out.println("Last Name: "+getLastName());
		System.out.println("Gender: "+getGender());
		System.out.println("Phone Number: "+getPhoneNo());
	}
	
	
}
