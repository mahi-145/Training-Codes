import java.util.Scanner;
public class TestPerson 
{

	public static void main(String[] args) 
	{
		long phoneNumber;
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter phone number");
		phoneNumber = sc.nextLong();
		
		Person p1=new Person("Divya","Bharti",'F',phoneNumber);	
		Person p2=new Person();
		
		p1.dispPerson(); 
		
		p2.dispPerson();

	}

}