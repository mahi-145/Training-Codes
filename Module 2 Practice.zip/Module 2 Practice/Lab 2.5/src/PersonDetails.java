enum Gender
{
	F,M;
	
}
public class PersonDetails {

	public static void main(String[] args) 
	{
		Person p1=new Person();	
		
		Gender gen = Gender.F;
		
		p1.setFirstName("Divya");
		p1.setLastName("Bharti");
		p1.setGender(gen);
		
		System.out.println("Person Details: ");
		System.out.println("___________________");
		System.out.println("First Name: "+p1.getFirstName()); // for calling ..getter function is used
		System.out.println("Last Name: "+p1.getLastName());
		System.out.println("Gender: "+p1.getGender());

	}

}
