
public interface Printable 
{
	static double PI=3.14566;
	void print(); 	//By default functions are abstract and 
					//public no need to write public and abstract
}
