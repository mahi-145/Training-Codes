import java.util.Scanner;
public class TestBankAppDemo {

	public static void main(String[] args) //throws LowBalanceExcpetion
	{
		Scanner sc=new Scanner(System.in);
		int currentBalance=6000;
		
		System.out.println("Enter the withdrawal Amount");
		int withdrawAmt=sc.nextInt();
		
		if(withdrawAmt<currentBalance)
		{
			System.out.println("OK u can withdraw");
		}
		
		else 
		{
			try 
			{
				throw new LowBalanceException("Check ur balance");
			} 
			catch (LowBalanceException e) 
			{
				System.out.println("Low balance");
				e.printStackTrace();
			}
		}

	}

}
