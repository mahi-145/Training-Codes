import static java.lang.Math.*;		//Feature1. Static Import 

class Parent
{
	public void print()
	{
		System.out.println("Parent :");
	}
//************************Feature 2.Var arg Feature**********************//
	public int add(int ... numbers)
	{
		int sum=0;
		for(int i=0;i<numbers.length;i++)
		{
			sum =sum + numbers[i];
		}
	return sum;
	}
}
class Child extends Parent
{
	@Override			//Feature3.Annotations 
	public void print()
	{
		System.out.println("Child :");
	}
}
public class TestJava5FeaturesDemo 
{

	public static void main(String[] args) 
	{
		System.out.println(" PI ="+PI);
		System.out.println(" cube of 2="+pow(2,3));
		
		Parent pp=new Parent();
		System.out.println("Addition is:"+pp.add(9,80,1));
	
//**************************Enhance for Loop***********************************//
		
		int marks[]=new int [3];
		marks[0]=90;
		marks[1]=10;
		marks[2]=40;
		String cityList[]={"Pune","Mumbai","Noida"};
		for(int tempMarks:marks)
		{
			System.out.println(" "+tempMarks);
		}
		for(String city:cityList)
		{
			System.out.println(" "+city);
		}
		
	}

}
