
public class TestInterfaceDemo 
{

	public static void main(String[] args) 
	{
		Printable p=new Box(8,9,2);	//p is in Stack, Box is dynamic Type.
		
		p.print();
		System.out.println("Volume of box: "+((Box)p).calcVol());
	}

}
