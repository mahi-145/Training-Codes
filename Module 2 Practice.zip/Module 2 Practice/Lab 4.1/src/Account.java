
public class Account extends Person
{
	private long accNum;
	private double balance;
	private double amount;
	Person accHolder;
	
	
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Account() 
	{
		
	}
	public Account(Person accHolder,long accNum, double balance) 
	{
		this.accHolder=accHolder;
		this.accNum = accNum;
		this.balance = balance;
	}
	
	@Override
	public String toString() {
		return "Account [accNum=" + accNum + ", balance=" + balance
				+ ", amount=" + amount + ", accHolder=" + accHolder + "]";
	}
	public void deposit(double amount)
	{
		balance=balance + amount;
	}
	public void withdraw(double amount)
	{
		balance=balance- amount;
	}
	public double getBalance()
	{
		return balance;
	}
}
