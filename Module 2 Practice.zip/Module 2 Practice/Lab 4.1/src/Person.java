
public class Person 
{
	private String name;
	private float age;
	
	public Person() {};
	
	public String getPerName() {
		return name;
	}

	public void setPerName(String perName) {
		this.name = perName;
	}

	public float getPerAge() {
		return age;
	}

	public void setPerAge(float perAge) {
		this.age = perAge;
	}

	public Person(String perName, float perAge) 
	{
		this.name = perName;
		this.age = perAge;
	}

	@Override
	public String toString() {
		return "Person [perName=" + name + ", perAge=" + age + "]";
	}
	
	
	
	
}
