import java.util.Random;
public class TestAccount {

	public static void main(String[] args) 
	{
		Random rd=new Random();
		int n=rd.nextInt(50)+1;
		
		Account acc1=new Account( new Person("Smith",40),n,2000);
		Account acc2=new Account(new Person("Kathy",40),n,3000);
		
		acc1.deposit(2000);
		acc2.withdraw(2000);
		
		System.out.println(acc1);
		System.out.println(acc2);
	}

}
