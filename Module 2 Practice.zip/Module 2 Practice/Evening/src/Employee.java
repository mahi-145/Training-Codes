
public class Employee
{
		private int empId;
		private String empName;
		private char empGender;
		private float empSalary;
		Date empDOJ;
		public Employee()
		{
			empId=0;
			empName="unknown";
			empGender=' ';
			empSalary=0.0f;
			empDOJ=new Date();
		}
		/*public Employee(int id, String en, char g,float sal)
		{
			empId = id;
			empName= en;
			empGender = g;
			empSalary =sal;
		}*/
		public Employee(int id, String en, char g,float sal,Date empDOJ)
		{
			this.empId = id;
			this.empName= en;
			this.empGender = g;
			this.empSalary =sal;
			this.empDOJ=empDOJ;
		}
		public String dispEmpInfo()
		{
			return "Employee [empID="+empId+","
					+ "empName="+empName+",empSal="+empSalary+",empDOJ="+empDOJ.dispDate()+"]";
		}
		
		
		
		


}
