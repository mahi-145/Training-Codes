import java.util.Scanner;


public class TestAggregationEmployee 
{

	public static void main(String[] args) 
	{
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter the number of Employees");
		int n=sc.nextInt();
		
		Employee allEmps[]=new Employee[n];
		String names= null;
		Date allDOJs[]=new Date[n];
		
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter Employee's name:");
			names=sc.next();
			
			System.out.println("Enter employee Id:");
			int empId=sc.nextInt();
			
			System.out.println("Enter Gender of Employee:");
			String empgen=sc.next();
			char gender=empgen.charAt(0);
			
			System.out.println("Enter Salary of Employee:");
			float empSal=sc.nextFloat();
			
			System.out.println("Enter  DOJ in the format dd mm yy:");
			int day=sc.nextInt();
			int mon=sc.nextInt();
			int year=sc.nextInt();
			
			allDOJs[i]=new Date(day,mon,year);
			allEmps[i]=new Employee(empId,names,gender,empSal,allDOJs[i]);
		}
		
		for(int j=0;j<n;j++)
		{
			
			System.out.println(allEmps[j].dispEmpInfo());
		}

		
		

	}

}
