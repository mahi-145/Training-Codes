
public class Person 
{
	private String perName;
	private int personAge;
	private String panNo;
	public String getPerName() {
		return perName;
	}
	public void setPerName(String perName) {
		this.perName = perName;
	}
	public int getPersonAge() {
		return personAge;
	}
	public void setPersonAge(int personAge) {
		this.personAge = personAge;
	}
	public String getPanNo() {
		return panNo;
	}
	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}
	public Person(String perName, String panNo, int personAge) 
	{
		
		this.perName = perName;
		this.personAge = personAge;
		this.panNo = panNo;
	}
	@Override
	public String toString() {
		return "Person [perName=" + perName + ", personAge=" + personAge
				+ ", panNo=" + panNo + "]";
	}
	@Override 
	public boolean equals(Object obj)
	{
		Person tempPerson=(Person)obj;
		if(this.panNo==tempPerson.panNo)
			return true;
		else
			return false;
	}
	@Override
	public int hashCode()
	{
		 return panNo.hashCode();		
	}
	
}
