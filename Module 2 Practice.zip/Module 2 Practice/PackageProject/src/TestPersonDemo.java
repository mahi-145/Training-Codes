
public class TestPersonDemo {

	public static void main(String[] args)
	{
		Person p1=new Person("Vaishali S","CBH78GOP",20);
		Person p2=new Person("Vaish S","CKH78GOP",40);
		Person p3=new Person("Vaishali S","CBH78GOP",20);
		
		Integer i1=new Integer(20);
		Integer i2=new Integer(30);
		Integer i3=new Integer(20);
		
		
		System.out.println("i1="+i1);
		System.out.println("i2="+i2);
		System.out.println("i3="+i3);
		
		if(i1.equals(i2))
		{
			System.out.println("Same");
		}
		else
			System.out.println("Not Same");
		System.out.println("Hashcode of p1 "+p1.hashCode());
		System.out.println("Hashcode of p2 "+p2.hashCode());
		System.out.println("Hashcode of p3 "+p3.hashCode());
		
		System.out.println("Hashcode of i1 "+i1.hashCode());
		System.out.println("Hashcode of i2 "+i2.hashCode());
		System.out.println("Hashcode of i3 "+i3.hashCode());
		
		
		/*if(p1.equals(p3)) 			//p1,p2 and p3 are the references in Stack Memory
			System.out.println(" Same");
		else
			System.out.println("Not Same");*/
			

	}

}
