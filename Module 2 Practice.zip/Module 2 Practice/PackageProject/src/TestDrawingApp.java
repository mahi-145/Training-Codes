
public class TestDrawingApp 
{

	public static void main(String[] args)
	{
		Shape sh =new Circle(5);
		Shape sh2=new Sphere(3);
		
		System.out.println("Area of Circle:"+sh.calcArea());
		System.out.println("Perimeter of Circle: "+sh.calcPerimeter());
		System.out.println("Volume of Sphere: "+sh2.calcArea());
		System.out.println("Surface Area of Sphere: "+sh2.calcPerimeter());
	}

}
