
public class Sphere extends Circle
{
	public Sphere(){}
	public Sphere(int radius)
	{
		super(radius);
		
	}
	public double calcArea()
	{
		return ((4/3)*Math.PI*(Math.pow(getRadius(),3)));
	}
	public double calcPerimeter()
	{
		return ((4*Math.PI*getRadius()*getRadius()));
	}
}
