package com.cg.hbms.controller;

import java.util.ArrayList;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.hbms.dto.BookingDetails;
import com.cg.hbms.dto.Hotels;
import com.cg.hbms.dto.RoomDetails;
import com.cg.hbms.service.IHBMSService;


@Controller
public class HBMSController 
{
	@Autowired
	IHBMSService hbmsService;
	@RequestMapping(value="all",method=RequestMethod.GET)
	public String getAll()
	{
		return "Welcome";
	}
	@RequestMapping(value="goback",method=RequestMethod.GET)
	public String goBack()
	{
		return "Options";
	}
	@RequestMapping(value="frmlogin",method=RequestMethod.POST)
	public ModelAndView getOptions(@RequestParam("uid")String id,@RequestParam("pass")String pswrd, HttpServletRequest request)
	{
		if(hbmsService.validateUserId(id)&&hbmsService.validateUserPass(pswrd))
		{
			request.getSession(true).setAttribute("uid", id);
			return new ModelAndView("Options");
		}
		else
		{
			return new ModelAndView("Welcome","msg","Invalid Login Credentials!");
		}	
	}
	@RequestMapping(value="search",method=RequestMethod.GET)
	public String search()
	{
		return "SearchHotel";
	}
	@RequestMapping(value="searchHotel",method=RequestMethod.GET)
	public ModelAndView searchHotel(@RequestParam("city") String city, Model m)
	{
		String output = city.substring(0, 1).toUpperCase() + city.substring(1);
		List<Hotels> myData = hbmsService.showAllHotels(city);
		List<Hotels> myData2 = hbmsService.showAllHotels(output);
		if(!myData.isEmpty())
		{
			
			return new ModelAndView("AllHotels","retHotel",myData);
		}
		else if(!myData2.isEmpty()){
			return new ModelAndView("AllHotels","retHotel",myData2);
		}
		else
		{
			return new ModelAndView("SearchHotel","msg","Sorry..!!No Hotels Available in this City!");
		}
	}
	@RequestMapping(value="room",method=RequestMethod.GET)
	public ModelAndView searchRoom(@RequestParam("htlid") String hotelid)
	{
		List<RoomDetails> myRoom = hbmsService.showRooms(hotelid);
		if(!myRoom.isEmpty())
		{
		
			return new ModelAndView("AllRooms","retRoom",myRoom);
		}
		else
		{
			return new ModelAndView("AllHotels","msg","Sorry...!!No Rooms Available in " + hotelid);
		}	
	}

	@RequestMapping(value="book",method=RequestMethod.GET)
	public ModelAndView bookHotel(@RequestParam("rid") String roomid, 
			@ModelAttribute("my")BookingDetails book,Model model, HttpServletRequest request)
	{	
		
		String id = (String) request.getSession(false).getAttribute("uid");
		model.addAttribute("roomid", roomid);
		return new ModelAndView("BookHotel","userid",id);
	}
	@RequestMapping(value="data", method=RequestMethod.POST)
	public ModelAndView bookHotels(@ModelAttribute("my") BookingDetails book)
	{	
		Date chkin=book.getBookFrom();
		Date chkout=book.getBookTo();
		String rmid=book.getRoomId();
		LocalDate checkin=chkin.toLocalDate();
		LocalDate checkout=chkout.toLocalDate();
		if(checkin.isAfter(LocalDate.now())&& checkout.isAfter(checkin))
		{
			double total=hbmsService.generateBill(rmid,checkin,checkout);
			book.setAmount(total);
			hbmsService.addBooking(book);
			hbmsService.updateAvail(rmid);
			return new ModelAndView("success","temp",total);
		}
		else
		{
			return new ModelAndView("BookHotel","msg","Check In Date should not be less than current date And Check Out date should not be less than checkIn date");
		}
	}
	@RequestMapping(value="viewBooking",method=RequestMethod.GET)
	public ModelAndView viewBooking(HttpServletRequest request)
	{
		String user_id = (String) request.getSession(false).getAttribute("uid");
		
		List<BookingDetails> bookData = hbmsService.getBookingStatus(user_id);
		if(!bookData.isEmpty())
		{
			
			return new ModelAndView("ViewBookingStatus","bookingStatus",bookData);
		}
		else
		{
			return new ModelAndView("Error","msg","No Bookings yet");
		}	
	}
	@RequestMapping(value="cancel",method=RequestMethod.GET)
	public ModelAndView cancelUser(HttpServletRequest request)
	{
		String user_id = (String) request.getSession(false).getAttribute("uid");
		List<BookingDetails> bookData = hbmsService.getBookingStatus(user_id);
		Date date;
		LocalDate bdate = null;
		
		List<BookingDetails> realData = new ArrayList<>();
		
		if(!bookData.isEmpty())
		{
			for(BookingDetails b: bookData)
			{
				date = b.getBookFrom();
				bdate = date.toLocalDate();
				if(bdate.isAfter(LocalDate.now()))
				{
					realData.add(b);
				}
			}
			if(!realData.isEmpty()) {
				return new ModelAndView("ViewCancelBooking","bookingStatus",realData);
			}
			else{
				return new ModelAndView("Error","msg","No bookings available!");
			}
						
		}
		else
		{
			return new ModelAndView("Error","msg","You have not made any Bookings");
		}
			
	}
	@RequestMapping(value="bCancel",method=RequestMethod.GET)
	public String bookCancelled(@RequestParam("id") Integer bookid)
	{
		hbmsService.deleteBooking(bookid);
		return "Cancelled";
	}
}
