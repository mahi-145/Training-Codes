package com.cg.hbms.dao;

import java.time.LocalDate;
import java.util.List;

import com.cg.hbms.dto.RoomDetails;
import com.cg.hbms.dto.BookingDetails;
import com.cg.hbms.dto.Hotels;
 
public interface IHBMSDao 
{
	public List<Hotels>showAllHotels(String city);
	public List<BookingDetails> getBookingStatus(String user_id);
	public List<RoomDetails> showRooms(String hotelname);
	public String addBooking(BookingDetails book);
	public double generateBill(String roomId, LocalDate bookFrom,LocalDate bookTo);
	public void deleteBooking(Integer bookid);
	public List<String>getAllUserIds();
	public List<String> getAllUserPass();
	public void updateAvail(String roomid);
	public List<RoomDetails> getRoomDetails(String rid);
}
