package com.cg.hbms.dao;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.hbms.dto.BookingDetails;
import com.cg.hbms.dto.Hotels;
import com.cg.hbms.dto.RoomDetails;


@Repository("hbmsDao")
public class HBMSDaoImpl implements IHBMSDao
{
	@PersistenceContext
	EntityManager em;

	@Override
	public List<Hotels> showAllHotels(String city)
	{
		Query searchQry=em.createQuery("Select h From Hotels h WHERE h.city=:city");
		searchQry.setParameter("city", city);
		return searchQry.getResultList();
	}

	@Override
	public List<BookingDetails> getBookingStatus(String user_id) 
	{
		Query searchQry2 = em.createQuery("Select b FROM BookingDetails b WHERE userId=:uid");
		searchQry2.setParameter("uid", user_id);
		return searchQry2.getResultList();
	}
	@Override
	public void deleteBooking(Integer bookid) 
	{
		Query qry=em.createQuery("Delete From BookingDetails Where id=:bid");
		qry.setParameter("bid", bookid);
		qry.executeUpdate();	
	}

	@Override
	public List<RoomDetails> showRooms(String hotel_id) 
	{
		
		TypedQuery<RoomDetails> q = em.createNamedQuery("getRoomDetails", RoomDetails.class);
		q.setParameter("h", hotel_id);
		return q.getResultList();
	}

	@Override
	public double generateBill(String roomId, LocalDate bookFrom,LocalDate bookTo) 
	{
		Query billQry=em.createQuery("SELECT r.perNightRate FROM RoomDetails r "
				+ "WHERE room_id=:rid");
		billQry.setParameter("rid",roomId);
		return billQry.executeUpdate();
	}

	@Override
	public String addBooking(BookingDetails book) 
	{
		em.persist(book);
		em.flush();
		return String.valueOf(book.getId());
	}

	@Override
	public List<String> getAllUserIds() 
	{
		Query querytwo=em.createQuery("SELECT id FROM User");
		return querytwo.getResultList();
	}
	@Override
	public List<String> getAllUserPass() 
	{
		Query querythree=em.createQuery("SELECT password FROM User");
		return querythree.getResultList();
	}

	@Override
	public void updateAvail(String roomid) 
	{
		Query updateQry=em.createQuery("UPDATE RoomDetails r SET r.availability='NO' WHERE room_id=:rid ");
		updateQry.setParameter("rid",roomid);
		updateQry.executeUpdate();
		
	}

	@Override
	public List<RoomDetails> getRoomDetails(String rid)
	{
		Query queryfour=em.createQuery("FROM RoomDetails WHERE id=:rid");
		queryfour.setParameter("rid", rid);
		return queryfour.getResultList();
	}
	
}
