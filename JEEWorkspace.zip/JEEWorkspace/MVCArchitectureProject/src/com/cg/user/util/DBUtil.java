package com.cg.user.util;

import java.sql.*;

import javax.sql.DataSource;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.cg.user.exception.LoginException;


public class DBUtil 
{
	public static Connection getCon() throws LoginException
	{
		Connection con=null;
		InitialContext context;
		
		try 
		{
			context=new InitialContext();
			DataSource ds=(DataSource)context.lookup("java:/jdbc/OracleDS");
			con=ds.getConnection();
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
	return con;
	}
}
