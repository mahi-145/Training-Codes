package com.cg.user.service;

import java.sql.*;

import com.cg.user.dto.*;
import com.cg.user.exception.LoginException;

public interface LoginService 
{
	public Login getUserByUnm(String unm) throws LoginException;
}
