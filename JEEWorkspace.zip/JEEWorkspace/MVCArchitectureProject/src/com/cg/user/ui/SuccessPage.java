package com.cg.user.ui;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/SuccessPage")
public class SuccessPage extends HttpServlet
{
	private static final long serialVersionUID = 1L;
       
   ServletConfig cg=null;
    public SuccessPage() 
    {
        super();
       
    }

	public void init(ServletConfig config) throws ServletException
	{
		super.init(config);
		cg=config;
	}

	
	public void destroy() 
	{	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException
	{
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		PrintWriter pw=response.getWriter();
		HttpSession ses=request.getSession(true);
		String name=(String)ses.getAttribute("UserNameObj");
		
		pw.println("<b>Welcome To EMS : "+name+" You are a valid user </b><br>");
		pw.println("<hr color='green' size='3'> You can perform all emp operations<br/>");
		pw.println("<a href=''>Add Emp</a><br/>");
		pw.println("<a href=''>List All Emp</a><br/>");
		pw.println("<a href=''>Delete Emp</a><br/>");
		pw.println("<a href=''>Update Emp</a><br/>");
	}

}
