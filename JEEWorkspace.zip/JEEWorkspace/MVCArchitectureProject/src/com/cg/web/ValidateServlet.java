package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/ValidateServlet")
public class ValidateServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
   
    public ValidateServlet()
    {
        super();
        
    }


	public void init(ServletConfig config) throws ServletException
	{
		
	}

	
	public void destroy() 
	{
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException
	{
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		PrintWriter out=response.getWriter();
		String unm=request.getParameter("txtName");
		String pwd=request.getParameter("txtPwd");
		
		if(unm.equals("admin")&&
				(pwd.equals("admin")))
		{
			RequestDispatcher rdSuccess=request.getRequestDispatcher("htmls/User_Info.html");
			rdSuccess.forward(request,response);
		}
		else
		{
			RequestDispatcher rdFailure=
					request.getRequestDispatcher("HTMLfiles/Login.html");
			rdFailure.forward(request,response);
		}
	}

}
