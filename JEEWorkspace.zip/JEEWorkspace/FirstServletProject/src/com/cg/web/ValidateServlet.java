package com.cg.web;

import java.io.*;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dto.*;
import com.cg.service.*;



@WebServlet("/ValidateServlet")
public class ValidateServlet extends HttpServlet 
{
	LoginService logService=null;
	private static final long serialVersionUID = 1L;
       
    
    public ValidateServlet() 
    {
        super();
        
    }

	
	public void init(ServletConfig config) throws ServletException
	{
		
	}

	public void destroy()
	{
		System.out.println("Destroy is callled");
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		doPost(request,response);
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		logService=new LoginServiceImpl();
		String unm=request.getParameter("txtName");
		String pass=request.getParameter("txtPwd");
		PrintWriter pw=response.getWriter();
		try 
		{
			Login usr= logService.getUserByUnm(unm);
			if(usr.getUserName().equalsIgnoreCase(unm)&&
					(usr.getPassword().equalsIgnoreCase(pass)))
			{
				RequestDispatcher rdSuccess=request.getRequestDispatcher("SuccessServlet");
				rdSuccess.forward(request,response);
			}
			else
			{
				
				RequestDispatcher rdFailure=
						request.getRequestDispatcher("HTMLfiles/Login.html");
				rdFailure.forward(request,response);
			}
		} 
		catch (SQLException e)
		{
			pw.println("You are invalid user type correct username and password");
			e.printStackTrace();
		}
		
	}

}
