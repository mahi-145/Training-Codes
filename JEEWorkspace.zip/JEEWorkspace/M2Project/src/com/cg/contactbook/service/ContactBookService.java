package com.cg.contactbook.service;

import com.cg.contactbook.bean.*;
import com.cg.contactbook.exception.*;

public interface ContactBookService 
{
	public int addEnquiry(EnquiryBean enqry)throws ContactBookException;
	public EnquiryBean getEnquiryDetails(int EnquiryID)throws ContactBookException;
	
	public boolean validateContactNo(Long ContactNo)throws ContactBookException;
	public boolean validateEnqryId(int enqryId) throws ContactBookException;
	public boolean validatePDomain(String pDomain) throws ContactBookException;
	public boolean validatePLocation(String pLocation) throws ContactBookException;
	public boolean validateLastName(String lName) throws ContactBookException;
	public boolean validateFirstName(String fName) throws ContactBookException;
}
