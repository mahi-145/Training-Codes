package com.cg.contactbook.service;

import java.util.Iterator;
import java.util.regex.Pattern;

import com.cg.contactbook.bean.*;
import com.cg.contactbook.dao.*;
import com.cg.contactbook.exception.*;


public class ContactBookServiceImpl implements ContactBookService
{
	ContactBookDao cbDao=null;
	public ContactBookServiceImpl()
	{
		cbDao = new ContactBookDaoImpl();
	}

	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException
	{
		
		return cbDao.addEnquiry(enqry);
	}

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID)throws ContactBookException 
	{
		
		return cbDao.getEnquiryDetails(EnquiryID);
	}

	@Override
	public boolean validateContactNo(Long ContactNo)throws ContactBookException
	{
		String phPattern="[7-9][0-9]{9}";
		
		if(Pattern.matches(phPattern,new Long(ContactNo).toString()))
		{
			return true;
		}
		else
		{
			throw new ContactBookException("Provide Valid Mobile Number");
		}
	}
	@Override
	public boolean validateFirstName(String fName)throws ContactBookException
	{
		String namePattern="[A-Z][a-z]{1,20}";
		if(Pattern.matches(namePattern,fName))
		{
			return true;
		}
		else
		{
			throw new ContactBookException("only characaters are allowed"
					+ " First letter Should be capital for example Mahima");
		}
	}
	@Override
	public boolean validateLastName(String lName)throws ContactBookException
	{
		String lNamePattern="[A-Z][a-z]{1,20}";
		if(Pattern.matches(lNamePattern,lName))
		{
			return true;
		}
		else
		{
			throw new ContactBookException("only characaters are allowed"
					+ " First letter Should be capital for example Agrawal");
		}
	}
	@Override
	public boolean validatePLocation(String pLocation)throws ContactBookException
	{
		String namePattern="[A-Z][a-z]{1,20}";
		if(Pattern.matches(namePattern,pLocation))
		{
			return true;
		}
		else
		{
			throw new ContactBookException("only characaters are allowed"
					+ " First letter Should be capital for example Pune");
		}
	}
	@Override
	public boolean validatePDomain(String pDomain)throws ContactBookException
	{
		String namePattern="[A-Z][a-z]{1,20}";
		if(Pattern.matches(namePattern,pDomain))
		{
			return true;
		}
		else
		{
			throw new ContactBookException("only characaters are allowed"
					+ " First letter Should be capital for example Pune");
		}
	}
//************Validation of Enquiry Id************///
	@Override
	public boolean validateEnqryId(int enqryId) throws ContactBookException 
	{

		String numPattern="[1-9][0-9]{3}";
		int count=0;
		
		Iterator it=cbDao.getAllEnqryId().iterator();
		
		while(it.hasNext())
		{
			int id=(int)it.next();
			if(enqryId==id)
			{
				count=1;
				break;
			}
		}
		if(count==1)
		{	
			if(Pattern.matches(numPattern,new Integer(enqryId).toString()))
			{
				return true;
			}
			else
			{
				throw new ContactBookException("Minimum 4 digits are allowed in Mobile Id");
			}
		}
		else{
			return false;
		}
		
	}
}
