package com.cg.contactbook.util;

import java.io.*;
import java.sql.*;
import java.util.*;
import com.cg.contactbook.exception.*;


public class DBUtil 
{
	static String dbunm=null;
	static String dbpswd=null;
	static String url=null;
	
	
	public static Connection getCon()		//gives connection to oracle db
			throws IOException,Exception,ContactBookException,SQLException
	{
		Connection con=null;
		Properties dbInfoProps=DBUtil.getProp();
		
		url=dbInfoProps.getProperty("dbURL");
		dbunm=dbInfoProps.getProperty("dbUser");
		dbpswd=dbInfoProps.getProperty("dbPswd");
		
		if(con==null)
		{
			con=DriverManager.getConnection(url, dbunm, dbpswd);
		}
		return con;
	}
	public static Properties getProp()
			throws Exception,ContactBookException
	{
		Properties props=null;
		FileReader fr =null;

		props=new Properties();
		fr=new FileReader("resources/contactbookInfo.properties");
		props.load(fr);
		return props;
	}
}
