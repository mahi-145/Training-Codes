package com.cg.contactbook.ui;

import java.util.*;

import com.cg.contactbook.exception.*;
import com.cg.contactbook.service.*;
import com.cg.contactbook.bean.*;
import com.cg.contactbook.dao.*;

public class Client
{
	static Scanner sc=null;
	static ContactBookService cbSer=null;
	static ContactBookDao cbDao=null;

	public static void main(String[] args) 
	{
		cbSer=new ContactBookServiceImpl();
		cbDao=new ContactBookDaoImpl();
		sc=new Scanner(System.in);
		System.out.println("****************Global Recruitments*********************");
		while(true)
		{
			System.out.println("Choose an Operation");
			System.out.println("1.Enter Enquiry Details\n"
					+ "2.View Enquiry Details\n"
					+ "0.Exit");
			System.out.println("*****************************");
			System.out.print("Please Enter a choice: ");
			int choice=sc.nextInt();
			System.out.println("*****************************");
			switch(choice)
			{
			case 1: insertDetails();
			break;
			case 2: viewDetails();
			break;
			default:
				{
					System.out.println("Thank You For Selecting Us");
					System.exit(0);
				
				}

			}
		}
	}
	public static void insertDetails()
	{

		System.out.println("Enter First Name :");
		String fnm=sc.next();
		try
		{

			if(cbSer.validateFirstName(fnm))
			{
				System.out.println("Enter Last Name :");
				String lnm=sc.next();
				if(cbSer.validateLastName(lnm))	
				{	
					System.out.println("Enter Contact Number :");
					long phone=sc.nextLong();
					if(cbSer.validateContactNo(phone))
					{
						System.out.println("Enter Preferred Domain :");
						String dom=sc.next();
						if(cbSer.validatePDomain(dom))
						{
							System.out.println("Enter Preferred Location");
							String loc=sc.next();
							System.out.println("*****************************");
							
							EnquiryBean eb=new EnquiryBean();
							
							eb.setfName(fnm);
							eb.setlName(lnm);
							eb.setContactNo(phone);
							eb.setpDomain(dom);
							eb.setpLocation(loc);
							
							int id;
							id = cbSer.addEnquiry(eb);
							if(id>0)
							{
								System.out.println("Thank You "+fnm+" "+lnm+
										" your Unique Id is" +id
										+ " we will contact you shortly.");
								System.out.println("*****************************");
							}
							
						} 
					}
				}
			}
		}
		
		catch (ContactBookException e)
		{
			System.out.println(e.getMessage());
		}

	}

	public static void viewDetails()
	{
		System.out.println("Enter Enquiry No. :");
		int id=sc.nextInt();
		System.out.println("***************************");
		try
		{
			if(cbSer.validateEnqryId(id))
			{
				EnquiryBean eb=cbSer.getEnquiryDetails(id);
				System.out.println("Id \tFirst Name\tLast Name\tContact No.\t"
						+ "Preferred Domain\tPreferred Location");

				System.out.println(eb.getEnqryId()+"\t"+eb.getfName()+"\t"+eb.getlName()+"\t"+eb.getContactNo()+"\t"
						+eb.getpDomain()+"\t"+eb.getpLocation()+"\t");		
			}
			else
				System.out.println("Sorry no Details Found!!");
		}

		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

}



