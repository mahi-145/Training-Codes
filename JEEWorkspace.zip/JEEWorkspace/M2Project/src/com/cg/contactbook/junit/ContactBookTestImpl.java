package com.cg.contactbook.junit;
import junit.framework.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.contactbook.bean.*;
import com.cg.contactbook.dao.*;
import com.cg.contactbook.exception.*;


public class ContactBookTestImpl 
{
	static ContactBookDao cbDao = null;
	static EnquiryBean eb = null;
    
    @BeforeClass
    public static void beforeClass() {
        
        cbDao = new ContactBookDaoImpl();
        eb = new EnquiryBean();
    }
    
    @Test
    public void testaddEnquiry() throws ContactBookException {
        Assert.assertEquals(1, cbDao.addEnquiry(eb));
    }
    
    @Test(expected = Exception.class)
    public void testaddEnquiry2() throws Exception {
        
        Assert.assertEquals(1, cbDao.addEnquiry(eb));
    }
    
    
    @Test
    public void testaddEnquiry3() throws ContactBookException {
        Assert.assertNotNull(cbDao.addEnquiry(eb));
    }
    
    @Test
    public void testgenerateEnqryId() throws ContactBookException {
        Assert.assertEquals(1041,cbDao.generateEnqryId());
    }
    @Test(expected = Exception.class)
    public void testgenerateEnqryId1() throws Exception {
        Assert.assertEquals(1001,cbDao.generateEnqryId());
    }
    
}
