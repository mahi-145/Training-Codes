package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/UrlRewriteServlet")
public class UrlRewriteServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	
    int count;   
    ServletConfig cg=null;
    public UrlRewriteServlet() {
        super();
       
    }

	
	public void init(ServletConfig config) throws ServletException 
	{
		super.init(config);
		cg=config;
	}

	
	public void destroy() {
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException
	{
		String id=request.getParameter("id");
		if(id==null)
		{
			id="1";
			count=Integer.parseInt(id);
			count++;
		}
		else
		{
			count=Integer.parseInt(id);
			count++;
		}
		PrintWriter pw=response.getWriter();
		pw.println("<b>I visited :"+count +" times.</b>");
		pw.println("<br>Do you want to visit me again?");
		pw.println("<a href='/SessionProject/UrlRewriteServlet?id="+count+"'>Click Here"
				+"To Visit Again</a>");
	}

}
