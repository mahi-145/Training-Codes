package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/BookCatalogServlet")
public class BookCatalogServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
   
    public BookCatalogServlet()
    {
        super();
       
    }

	
	public void init(ServletConfig config) throws ServletException 
	{
		
	}

	
	public void destroy() 
	{
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException
	{
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		PrintWriter pw=response.getWriter();
		pw.println("<body bgcolor='Skyblue'>");
		pw.println("<h1>Select Book</h1>");
		
		pw.println("<form action='/SessionProject/CartServlet'>");
		
		pw.println("<Select name='txtBook'>");
		pw.println("<option value='C'>C</option>");
		pw.println("<option value='Java'>Java</option>");
		pw.println("<option value='Oracle'>Oracle</option>");
		pw.println("<option value='HTML'>HTML</option>");
		pw.println("</select>");
		
		pw.print("<input type='submit' value='Add to Cart' name='btnAddCart'>");
		
		pw.println("</form>");
		pw.println("</body>");
		
	}

}
