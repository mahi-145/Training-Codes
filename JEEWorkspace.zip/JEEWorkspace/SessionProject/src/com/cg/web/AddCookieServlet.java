package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/AddCookieServlet")
public class AddCookieServlet extends HttpServlet 
{
	int count=0;
	private static final long serialVersionUID = 1L;
   
    public AddCookieServlet()
    {
        super();
        
    }

	
	public void init(ServletConfig config) throws ServletException 
	{
		
	}

	
	public void destroy() 
	{
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException
	{
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		String nm=request.getParameter("txtName");
		Cookie cookArr[]=request.getCookies();
		Cookie myCookie=null;
		String cookName=null;
		if(cookArr==null)
		{
			count=1;
			cookName="UserName-"+count;
			myCookie=new Cookie(cookName,nm);
			response.addCookie(myCookie);
		}
		else
		{
			count=(cookArr.length+1);
			cookName="UserName-"+count;
			myCookie=new Cookie(cookName,nm);
			response.addCookie(myCookie);
		}
		PrintWriter out =response.getWriter();
		out.println("<br>Data is Added in the cookie");
		out.println("<a href='/SessionProject/GetCookieServlet'>"+"Get All Cookies</a>");
	}
}
