package com.cg.service;

import java.sql.SQLException;

import com.cg.dao.*;
import com.cg.dto.Register;

public class RegisterServiceImpl implements RegisterService
{
	RegisterDao regDao=null;
	public RegisterServiceImpl()
	{
		regDao=new RegisterdaoImpl();
	}
	@Override
	public int addRegisterDetails(Register reg) throws SQLException
	{
		return regDao.addRegisterDetails(reg);
	}
	
	
}
