package com.cg.dao;

import java.sql.*;

import com.cg.dto.*;

public interface RegisterDao 
{
	public int  addRegisterDetails(Register reg)throws SQLException;
}
