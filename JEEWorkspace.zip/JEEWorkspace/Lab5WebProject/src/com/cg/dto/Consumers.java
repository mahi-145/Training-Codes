package com.cg.dto;

public class Consumers 
{
	private int consNum;
	private String consName;
	private String address;
	public int getConsNum() {
		return consNum;
	}
	public void setConsNum(int consNum) 
	{
		this.consNum = consNum;
	}
	public String getConsName() 
	{
		return consName;
	}
	public void setConsName(String consName)
	{
		this.consName = consName;
	}
	public String getAddress() 
	{
		return address;
	}
	public void setAddress(String address)
	{
		this.address = address;
	}
	public Consumers(int consNum, String consName, String address) 
	{
		super();
		this.consNum = consNum;
		this.consName = consName;
		this.address = address;
	}
	
}
