package com.cg.dto;

import java.sql.Date;

public class BillDetails 
{
	private int billNum;
	private int cons_Num;
	private float currRead;
	private float lastRead;
	private float consumedUnit;
	private float netAmt;
	private Date billDate;
	public int getBillNum() {
		return billNum;
	}
	public void setBillNum(int billNum) {
		this.billNum = billNum;
	}
	public int getCons_Num() {
		return cons_Num;
	}
	public void setCons_Num(int cons_Num) {
		this.cons_Num = cons_Num;
	}
	public float getCurrRead() {
		return currRead;
	}
	public void setCurrRead(float currRead) {
		this.currRead = currRead;
	}
	public float getLastRead() {
		return lastRead;
	}
	public void setLastRead(float lastRead) {
		this.lastRead = lastRead;
	}
	public float getConsumedUnit() {
		return consumedUnit;
	}
	public void setConsumedUnit(float consumedUnit) {
		this.consumedUnit = consumedUnit;
	}
	public float getNetAmt() {
		return netAmt;
	}
	public void setNetAmt(float netAmt) {
		this.netAmt = netAmt;
	}
	public Date getBillDate() {
		return billDate;
	}
	public void setBillDate(Date billDate) {
		this.billDate = billDate;
	}
	public BillDetails(int billNum, int cons_Num, float currRead,
			float lastRead, float consumedUnit, float netAmt, Date billDate) {
		super();
		this.billNum = billNum;
		this.cons_Num = cons_Num;
		this.currRead = currRead;
		this.lastRead = lastRead;
		this.consumedUnit = consumedUnit;
		this.netAmt = netAmt;
		this.billDate = billDate;
	}
	
	
}
