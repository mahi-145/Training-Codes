package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.dto.Consumers;
import com.cg.exception.*;
import com.cg.user.dto.Login;
import com.cg.user.exception.LoginException;
import com.cg.util.DBUtil;

public class BillDaoImpl implements BillDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;

	@Override
	public int generateBillNum() throws BillException
	{
		int generatedId;
		con=DBUtil.getCon();
		String qry="SELECT seq_bill_num.NEXTVAL FROM DUAL";
		try
		{
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			generatedId=rs.getInt(1);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new BillException(e.getMessage());
		}
		finally
		{
			try
			{
				rs.close();
				st.close();
				con.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
				throw new BillException(e.getMessage());
			}
		}
		return generatedId;
	}

	@Override
	public int getConsumerNum() throws BillException 
	{
		int consNum=0;
		Consumers cons=null;
		con=DBUtil.getCon();
		String selQry="SELECT consumer_num FROM consumers";
		try
		{
			st=con.createStatement();
			rs=st.executeQuery(selQry);
			rs.next();
			consNum=rs.getInt(1);
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			throw new BillException(e.getMessage());
		}
		return consNum;
	}

	@Override
	public String getConsumerName(int consNum) throws BillException 
	{
		String name=null;
		try
		{
			con=DBUtil.getCon();
		
			String Qry="SELECT consumer_name FROM consumers WHERE consumer_num=?";
			pst=con.prepareStatement(Qry);
			pst.setInt(1,consNum);
			rs=pst.executeQuery();
		}
		catch(SQLException se)
		{
			throw new BillException(se.getMessage());
		}
		return name;
	}
}

