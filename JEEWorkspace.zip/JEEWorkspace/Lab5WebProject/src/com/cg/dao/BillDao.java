package com.cg.dao;

import com.cg.exception.BillException;
import com.cg.dto.*;


public interface BillDao 
{
	public int getConsumerNum() throws BillException;
	public int generateBillNum() throws BillException;
	public String getConsumerName(int consNum)throws BillException;
}
