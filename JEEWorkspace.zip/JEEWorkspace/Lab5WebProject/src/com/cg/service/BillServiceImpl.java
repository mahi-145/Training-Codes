package com.cg.service;

import com.cg.dao.*;
import com.cg.exception.BillException;

public class BillServiceImpl implements BillService
{
	BillDao bdao=null;
	public BillServiceImpl()
	{
		bdao =new BillDaoImpl();
	}
	@Override
	public int getConsumerNum() throws BillException 
	{
		return bdao.getConsumerNum();
	}

	@Override
	public int generateBillNum() throws BillException
	{
		
		return bdao.generateBillNum();
	}

}
