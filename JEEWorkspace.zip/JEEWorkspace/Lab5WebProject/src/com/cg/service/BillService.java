package com.cg.service;

import com.cg.exception.BillException;

public interface BillService
{
	public int getConsumerNum() throws BillException;
	public int generateBillNum() throws BillException;
}
