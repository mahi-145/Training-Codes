
abstract class Animal
{
	public abstract void sound();
	int no;
	public Animal() 
	{
		super();
	}
	public Animal(int no) 
	{
		super();
		this.no = no;
	}
	
	
	
}
public class Lion extends Animal
{
	public void sound()
	{
		System.out.println("Roar");
	}
	public static void main(String args[])
	{
		Lion obj=new Lion();
		obj.sound();
	}
}
