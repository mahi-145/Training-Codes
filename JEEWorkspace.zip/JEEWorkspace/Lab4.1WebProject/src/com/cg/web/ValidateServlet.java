package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dto.Register;
import com.cg.service.RegisterService;
import com.cg.service.RegisterServiceImpl;


@WebServlet("/ValidateServlet")
public class ValidateServlet extends HttpServlet
{
	RegisterService regSer=null;
	Register reg=null;
	private static final long serialVersionUID = 1L;
       
   
    public ValidateServlet()
    {
        super();
       
    }

	public void init(ServletConfig config) throws ServletException
	{
		
	}

	
	public void destroy()
	{
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException
	{
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		regSer=new RegisterServiceImpl();
		
		String fName = request.getParameter("txtfName");
		String lName = request.getParameter("txtlName");
		String pwd = request.getParameter("txtPwd");
		String gen = request.getParameter("gender");
		String[] skill = request.getParameterValues("skill");
		String city = request.getParameter("city");
		String skills=String.join(",", skill);
		
		try 
		{
			Register regs=RegisterService.addRegisterDetails()
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		
		
	}

}
