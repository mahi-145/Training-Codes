package com.cg.ctrl;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.ElectricityBill;
import com.cg.service.ElecBillService;
import com.cg.service.ElecBillServiceImpl;


@WebServlet("/ElecBillController")
public class ElecBillController extends HttpServlet
{
	private static final long serialVersionUID = 1L;
	ServletConfig cg=null;
	ElecBillService elecBillSer=null;
	ElectricityBill elecBill=null;
	public ElecBillController() 
	{
		super();

	}


	public void init(ServletConfig config) throws ServletException 
	{
		super.init(config);
		cg=config;
	}


	public void destroy() 
	{

	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		doPost(request,response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		String action=request.getParameter("action");
		RequestDispatcher rd=null;
		HttpSession session=null;
		PrintWriter out=response.getWriter();

		if(action!=null)
		{
			int dataAdded=0;
			try
			{
				/*******ShowUserInfo********/
				if(action.equals("ShowUserInfo"))
				{
					String unm=request.getParameter("txtUserName");
					String pw=request.getParameter("txtPassword");
					if(validateUser(unm,pw))
					{	
						rd=request.getRequestDispatcher("/UserInfo.html");
						rd.forward(request, response);
					}
					else
					{
						rd=request.getRequestDispatcher("ShowErrorPage");
						rd.forward(request, response);
					}
				}
				/******* End ShowUserInfo********/
				/*******AddBillData********/
				if(action.equals("AddBillData"))
				{
					out.print("Hello");
					String lMonReading=request.getParameter("LMonMeterReading");
					String CMonReading=request.getParameter("CMonMeterReading");
					String consumerNo=request.getParameter("txtConsumerNo");
					out.println(lMonReading+CMonReading+consumerNo);

					float lMonMeterReading=Float.parseFloat(lMonReading);
					float cMonMeterReading=Float.parseFloat(CMonReading);
					int consumerNumber=Integer.parseInt(consumerNo);
					elecBillSer=new ElecBillServiceImpl();

					if(elecBillSer.validateConsumerNumber(consumerNumber))
					{
						if(elecBillSer.validateLMonMeterReading(lMonMeterReading))
						{
							if(elecBillSer.validateCMonMeterReading(cMonMeterReading,lMonMeterReading))
							{
							
								float unitConsumed=elecBillSer.calcUnitConsumed(lMonMeterReading, cMonMeterReading);
								float netAmount=elecBillSer.calcNetAmount(unitConsumed);
								elecBill=new ElectricityBill();
								elecBill.setConsumerNumber(consumerNumber);
								elecBill.setCurrMonthReading(cMonMeterReading);
								elecBill.setUnitConsumed(unitConsumed);
								elecBill.setNetAmount(netAmount);
								dataAdded=elecBillSer.addBillDetails(elecBill);
								if(dataAdded==1)
								{
									session=request.getSession(true);
									session.setAttribute("ConsumerNameObj", elecBillSer.getConsumerName(consumerNumber));
									session.setAttribute("ConsumerNumberObj", consumerNumber);
									session.setAttribute("UnitConsumedObj", unitConsumed);
									session.setAttribute("NetAmountObj", netAmount);
									rd=request.getRequestDispatcher("SuccessElecBillPage");
									rd.forward(request, response);
								}
							}
						}
					}
					else
					{
						out.println("Invalid Consumer Number");
					}

				}
				}

					/*******End AddBillData********/

					catch(Exception e)
					{
						e.printStackTrace();
					}

				}
			}
			private boolean validateUser(String unm,String pw) throws IOException
			{		
				if(unm.equals("admin") && pw.equals("admin"))
				{
					return true;
				}
				else
				{
					return false;
				}

			}

		}
