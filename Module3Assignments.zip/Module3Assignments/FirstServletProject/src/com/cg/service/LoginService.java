package com.cg.service;

import java.sql.*;
import com.cg.dto.*;

public interface LoginService 
{
	public Login getUserByUnm(String unm) throws SQLException;
}
