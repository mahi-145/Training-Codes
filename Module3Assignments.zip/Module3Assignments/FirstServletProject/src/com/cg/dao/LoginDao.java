package com.cg.dao;

import java.sql.SQLException;

import com.cg.dto.*;

public interface LoginDao 
{
	public Login getUserByUnm(String unm) throws SQLException;
}
