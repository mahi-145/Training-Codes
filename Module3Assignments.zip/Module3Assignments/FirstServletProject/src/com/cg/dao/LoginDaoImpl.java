package com.cg.dao;

import java.sql.*;
import com.cg.dto.Login;
import com.cg.util.DBUtil;

public class LoginDaoImpl implements LoginDao
{
	Connection con=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	
	@Override
	public Login getUserByUnm(String unm) throws SQLException
	{
		Login user=null;
		con=DBUtil.getCon();
		System.out.println("Got Connection");
		String qry="SELECT * FROM users_142702 WHERE user_id=?";
		pst=con.prepareStatement(qry);
		pst.setString(1,unm);
		rs=pst.executeQuery();
		rs.next();
		user=new Login(rs.getString("user_id"),
				rs.getString("password"));
		return user;
	}
}
