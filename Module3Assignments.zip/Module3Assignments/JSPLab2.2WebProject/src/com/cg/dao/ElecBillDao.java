package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.dto.*;
import com.cg.exception.*;


public interface ElecBillDao
{
	List<Consumers>getAllConsumers()throws BillException;
	
	public Consumers searchConsumer(int consid) throws BillException;
	
	public int addBillDetails(ElectricityBill eBill) throws BillException;
	
	List<ElectricityBill>getAllBills(long consNum)throws BillException;
	
}
