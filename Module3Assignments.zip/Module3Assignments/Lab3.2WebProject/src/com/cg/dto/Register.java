package com.cg.dto;

public class Register 
{
	private String firstName;
	private String lastName;
	private String password;
	private String skillSet;
	private String city;
	private char Gender;
	public String getFirstName() 
	{
		return firstName;
	}
	public void setFirstName(String firstName) 
	{
		this.firstName = firstName;
	}
	public String getLastName()
	{
		return lastName;
	}
	public void setLastName(String lastName) 
	{
		this.lastName = lastName;
	}
	public String getPassword() 
	{
		return password;
	}
	public void setPassword(String password) 
	{
		this.password = password;
	}
	public String getSkillSet() 
	{
		return skillSet;
	}
	public void setSkillSet(String skillSet)
	{
		this.skillSet = skillSet;
	}
	public String getCity()
	{
		return city;
	}
	public void setCity(String city)
	{
		this.city = city;
	}
	public char getGender() 
	{
		return Gender;
	}
	public void setGender(char gender) 
	{
		Gender = gender;
	}
	public Register(String firstName, String lastName, String password,
			String skillSet, String city, char gender)
	{
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.password = password;
		this.skillSet = skillSet;
		this.city = city;
		Gender = gender;
	}
	public Register()
	{
		super();
		
	}
	
	
}
