package com.cg.mpa.dbutil;

import java.sql.Connection;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.cg.bill.exception.BillException;


public class DBUtil {

	public static Connection getCon() throws BillException {
		
		Connection con = null;
		InitialContext context;
		
		try {
			//database configure from wildfly DSN online
			//now no need to use DriverManager to get Connection
			context = new InitialContext();
			DataSource ds = (DataSource) context.lookup("java:/jdbc/OracleDS");
			con = ds.getConnection();
		}
		catch (Exception e) {
			throw new BillException(e.getMessage());
		}
		
		return con;
	}
	
	
}
