package com.cg.bill.dao;

import java.util.List;

import com.cg.bill.dto.BillDetails;
import com.cg.bill.dto.Consumer;
import com.cg.bill.exception.BillException;

public interface BillDao {

	public List<Consumer> getAllConsumers() throws BillException;
	public Consumer getConsumer(long cnum) throws BillException;
	public BillDetails getBillDetail(long cnum) throws BillException;
	public int addBillDetail(BillDetails bill)  throws BillException;

}
