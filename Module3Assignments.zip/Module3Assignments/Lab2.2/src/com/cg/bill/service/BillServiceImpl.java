package com.cg.bill.service;

import java.util.List;

import com.cg.bill.dao.BillDao;
import com.cg.bill.dao.BillDaoImpl;
import com.cg.bill.dto.BillDetails;
import com.cg.bill.dto.Consumer;
import com.cg.bill.exception.BillException;

public class BillServiceImpl implements BillService {

	BillDao bdao = new BillDaoImpl();
	@Override
	public List<Consumer> getAllConsumers() throws BillException {
		
		return bdao.getAllConsumers();
	}
	@Override
	public Consumer getConsumer(long cnum) throws BillException {
		
		return bdao.getConsumer(cnum);
	}
	@Override
	public BillDetails getBillDetail(long cnum) throws BillException {
		
		return bdao.getBillDetail(cnum);
	}
	@Override
	public int addBillDetail(BillDetails bill) throws BillException {
		
		return bdao.addBillDetail(bill);
	}

}
