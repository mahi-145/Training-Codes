package com.cg.service;

import java.util.List;

import com.cg.dto.Consumers;
import com.cg.dto.ElectricityBill;
import com.cg.exception.BillException;

public interface ElecBillService 
{
	List<Consumers>getAllConsumers()throws BillException;
	public Consumers searchConsumer(int consid) throws BillException;
	public int addBillDetails(ElectricityBill eBill) throws BillException;
	List<ElectricityBill>getAllBills(long consNum)throws BillException;
}
