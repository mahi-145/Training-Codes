package com.cg.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.GeneratedValue;

import com.cg.dto.Consumers;
import com.cg.dto.ElectricityBill;
import com.cg.exception.BillException;
import com.cg.util.DBUtil;

public class ElecBillDaoImpl implements ElecBillDao
{
	Connection con=null;
	PreparedStatement pst = null;
	@Override
	public List<Consumers> getAllConsumers() throws BillException 
	{
		List<Consumers>cList=new ArrayList();
		Statement st;
		try 
		{
			con=DBUtil.getConnection();
			st = con.createStatement();
			ResultSet rs=st.executeQuery(QueryMapper.SELECT_ALL_CONSUMERS);
			while(rs.next())
			{
				Consumers cons=new Consumers();
				cons.setConsNum(rs.getInt("Consumer_num"));
				cons.setConsName(rs.getString("Consumer_name"));
				cons.setAddress(rs.getString("address"));
				cList.add(cons);
			}
		}
		catch(SQLException se)
		{
			throw new BillException("Problem in Fetching Consumers");
		}
		return cList;
	}
	@Override
	public Consumers searchConsumer(int consid) throws BillException 
	{
		PreparedStatement pst;
		Consumers cons;
		try 
		{
			con=DBUtil.getConnection();
			pst=con.prepareStatement(QueryMapper.SELECT_CONSUMERS);
			pst.setInt(1,consid);
			ResultSet rs=pst.executeQuery();
			if(rs.next())
			{
				cons=new Consumers();
				cons.setConsNum(rs.getInt("consumer_num"));
				cons.setConsName(rs.getString("consumer_name"));
				cons.setAddress(rs.getString("address"));	
			}
			else
				 throw new BillException("Invalid ID");
		}
		catch (SQLException e)
		{
			 throw new BillException("Problem in Searching Consumer");
		}
	return cons;
	}
	@Override
	public int addBillDetails(ElectricityBill eBill) throws BillException
	{
		PreparedStatement pst;
		int dataAdded;
		try
		{
			con=DBUtil.getConnection();
			pst=con.prepareStatement(QueryMapper.INSERT_QUERY);
			pst.setLong(1,generateBillNumber());
			pst.setLong(2,eBill.getConsumerNumber());
			pst.setFloat(3,eBill.getCurrMonthReading());
			pst.setFloat(4, eBill.getUnitConsumed());
			pst.setFloat(5,eBill.getNetAmount());
			pst.setDate(6,Date.valueOf(eBill.getBillDate()));
			dataAdded=pst.executeUpdate();
		
		}
		catch(Exception e)
		{
			throw new BillException("Problem in Inserting Bill Details");
		}
		return dataAdded;
		
	}
	private int generateBillNumber() throws Exception
	{		
		int generatedVal=0;
		Statement st;
		ResultSet rs;
		try 
		{
			con=DBUtil.getConnection();
			st=con.createStatement();
			rs=st.executeQuery(QueryMapper.SELECT_SEQUENCE);
			rs.next();
			generatedVal=rs.getInt(1);
			
		}
		catch (Exception e) 
		{
			throw new Exception("Problem in generating Bill NUmber");
		} 
		return generatedVal;
	}
	@Override
	public List<ElectricityBill> getAllBills(long consNum) throws BillException
	{
		PreparedStatement pst;
		List<ElectricityBill>bList=new ArrayList();
		try
		{
			con=DBUtil.getConnection();
			pst=con.prepareStatement(QueryMapper.SELECT_BILL);
			pst.setLong(2,consNum);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				ElectricityBill eb= new ElectricityBill();
				eb.setBillNumber(rs.getLong("bill_num"));
				eb.setConsumerNumber(rs.getLong("cons_num"));
				eb.setCurrMonthReading(rs.getFloat("cur_reading"));
				eb.setUnitConsumed(rs.getFloat("unitconsumed"));
				eb.setNetAmount(rs.getFloat("netamount"));
				eb.setBillDate(rs.getDate("bill_date").toLocalDate());
				bList.add(eb);
			}
		}
		catch(SQLException se)
		{
			throw new BillException("Problem in Fetching Bills");
		}
		return bList;
	}
	


}
