package com.cg.uas.dao;

import java.util.List;
import com.cg.uas.dto.Applicant;
import com.cg.uas.dto.ProgramScheduled;
import com.cg.uas.exception.UniversityException;

public interface IUasDao {

	public List<ProgramScheduled> getProgramsScheduled() throws UniversityException;
	public int setNewApplicant(Applicant app) throws UniversityException;
//	public List<Applicant> getApplicant(int id) throws UniversityException;
	
	public String getProgramName(String pid) throws UniversityException;
	
	public Applicant getApplicant(int id) throws UniversityException;
}
