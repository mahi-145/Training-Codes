package com.cg.uas.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.uas.dao.IUasDao;
import com.cg.uas.dto.Applicant;
import com.cg.uas.dto.ProgramScheduled;
import com.cg.uas.exception.UniversityException;

@Service
@Transactional
public class UasService implements IUasService {

	@Autowired
	IUasDao uasDao;

	@Override
	public List<ProgramScheduled> getProgramsScheduled()
			throws UniversityException {
		return uasDao.getProgramsScheduled();
	}

	@Override
	public int setNewApplicant(Applicant app) throws UniversityException {

		return uasDao.setNewApplicant(app);
	}

	@Override
	public Applicant getApplicant(int id) throws UniversityException {
		
		return uasDao.getApplicant(id);
	}

	@Override
	public String getProgramName(String pid) throws UniversityException {
		
		return uasDao.getProgramName(pid);
	}

//	@Override
//	public List<Applicant> getApplicant(int id) throws UniversityException {
//		
//		return uasDao.getApplicant(id);
//	}

}
